ARVION - 15 SHORT VIDEOS FOR TIKTOK / YOUTUBE SHORTS

PRODUCTS INCLUDED (PRODUCTION ONLY):
01-03 OBD Active Exhaust Pro
04-06 MEDIA PRO Music Video Player
07-09 PIXEL CRITTERS 1.0
10-12 Retro Snake Classic
13-15 Kalendarz Zmian

TECHNICAL
- 1080x1920 9:16, 25 FPS, H.264 + AAC, 12.25 seconds per file
- Original synthesized instrumental (no commercial music samples used)
- English overlays, user-website visuals
- Videos are animated slide showcases using product images; they do not claim to be recorded live gameplay or demonstrations

PUBLISHING
Videos were created but not uploaded to TikTok, YouTube or Metricool.
For automated scheduled publishing, Metricool needs accessible public MP4 links.
Upload the 15 MP4s individually, e.g. to the public GitHub Pages repository,
then share their public links so the posts can be scheduled through the connected Metricool account.
Free plan scheduling limits may apply.
Captions and official Google Play package links are in CAPTIONS_EN_YOUTUBE_TIKTOK.txt.
YouTube audience settings should reflect each app's actual target audience.
If AI-generated artwork from the site materially depicts realistic synthetic scenes, apply relevant platform disclosures.

All marketing wording is based on the website descriptions and user-provided app list.
